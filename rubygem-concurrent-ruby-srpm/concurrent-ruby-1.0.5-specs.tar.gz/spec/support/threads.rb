THREADS = (RUBY_ENGINE == 'ruby' ? 100 : 10)

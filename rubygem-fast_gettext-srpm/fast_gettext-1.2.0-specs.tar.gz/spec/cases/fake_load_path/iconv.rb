#simulate file not found
raise LoadError